#include <bits/byteswap-common.h>
